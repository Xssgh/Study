package eco

import kotlin.random.Random

enum class SpawnMode { WOLF, SHEEP, CAVE }

class UserControl(val engine: EcosystemEngine) {
    var currentMode: SpawnMode = SpawnMode.SHEEP

    fun handleMouseClick(clickX: Float, clickY: Float) {
        when (currentMode) {
            SpawnMode.WOLF -> {
                val assignedCave = engine.caves.minByOrNull { cave ->
                    val dx = (clickX - cave.x).toDouble()
                    val dy = (clickY - cave.y).toDouble()
                    dx * dx + dy * dy
                }
                val homeX = assignedCave?.x ?: clickX
                val homeY = assignedCave?.y ?: clickY

                engine.animals.add(
                    Wolf(
                        x = clickX, y = clickY, homeX = homeX, homeY = homeY,
                        initEnergy = Random.nextInt(1000, 1501),
                        hungerThres = Random.nextInt(400, 801),
                        visionRange = Random.nextDouble(180.0, 320.0),
                        maxAgeLimit = Random.nextInt(2500, 3501)
                    )
                )
            }
            SpawnMode.SHEEP -> {
                engine.animals.add(
                    Sheep(
                        x = clickX, y = clickY,
                        initEnergy = Random.nextInt(700, 1001),
                        hungerThres = Random.nextInt(500, 801),
                        visionRange = Random.nextDouble(150.0, 250.0),
                        maxAgeLimit = Random.nextInt(1500, 2501)
                    )
                )
            }
            SpawnMode.CAVE -> {
                val newIndex = engine.caves.size + 1
                engine.caves.add(Cave(x = clickX, y = clickY, name = "Cave-$newIndex"))
            }
        }
    }

    fun saveSimulation() {
        SaveManager.save(engine)
    }

    fun loadSimulation() {
        SaveManager.load(engine)
    }
}