package eco

import java.io.File

object SaveManager {
    private val file = File("savegame.txt")

    fun save(engine: EcosystemEngine) {
        try {
            val sb = StringBuilder()

            // 동굴 저장 (CAVE|x|y|radius|name)
            engine.caves.forEach { cave ->
                sb.append("CAVE|${cave.x}|${cave.y}|${cave.radius}|${cave.name}\n")
            }

            // 풀 구역 저장 (GRASS|x|y|radius|maxHp|hp|growth)
            engine.grassZones.forEach { zone ->
                sb.append("GRASS|${zone.x}|${zone.y}|${zone.radius}|${zone.maxHp}|${zone.hp}|${zone.growth}\n")
            }

            // 동물 저장
            engine.animals.forEach { animal ->
                if (animal is Wolf) {
                    sb.append("WOLF|${animal.x}|${animal.y}|${animal.homeX}|${animal.homeY}|${animal.maxEnergy}|${animal.speed}|${animal.vision}|${animal.maxAge}|${animal.energy}|${animal.age}|${animal.angle}|${animal.state}|${animal.breedCount}|${animal.isAlpha}\n")
                } else if (animal is Sheep) {
                    sb.append("SHEEP|${animal.x}|${animal.y}|${animal.maxEnergy}|${animal.speed}|${animal.vision}|${animal.maxAge}|${animal.energy}|${animal.age}|${animal.angle}|${animal.state}|${animal.breedCount}|${animal.isAlpha}\n")
                }
            }

            file.writeText(sb.toString())
            println("[SYSTEM] 수동 파일 저장 성공: savegame.txt")
        } catch (e: Exception) {
            println("[ERROR] 저장 실패: ${e.message}")
        }
    }

    fun load(engine: EcosystemEngine) {
        try {
            if (!file.exists()) {
                println("[ERROR] 저장된 파일이 없습니다.")
                return
            }

            engine.caves.clear()
            engine.grassZones.clear()
            engine.animals.clear()

            file.forEachLine { line ->
                val tokens = line.split("|")
                if (tokens.isEmpty() || tokens[0].isBlank()) return@forEachLine

                when (tokens[0]) {
                    "CAVE" -> {
                        val cave = Cave(
                            x = tokens[1].toFloat(),
                            y = tokens[2].toFloat(),
                            radius = tokens[3].toFloat(),
                            name = tokens[4]
                        )
                        engine.caves.add(cave)
                    }
                    "GRASS" -> {
                        val zone = GrassZone(
                            x = tokens[1].toFloat(),
                            y = tokens[2].toFloat(),
                            radius = tokens[3].toFloat(),
                            maxHp = tokens[4].toInt(),
                            hp = tokens[5].toInt()
                        )
                        zone.growth = tokens[6].toInt()
                        engine.grassZones.add(zone)
                    }
                    "WOLF" -> {
                        val wolf = Wolf(
                            x = tokens[1].toFloat(),
                            y = tokens[2].toFloat(),
                            homeX = tokens[3].toFloat(),
                            homeY = tokens[4].toFloat(),
                            initEnergy = tokens[5].toInt(),
                            hungerThres = 400,
                            visionRange = tokens[7].toDouble(),
                            maxAgeLimit = tokens[8].toInt()
                        )
                        wolf.energy = tokens[9].toInt()
                        wolf.age = tokens[10].toInt()
                        wolf.angle = tokens[11].toDouble()
                        wolf.state = AnimalState.valueOf(tokens[12])
                        wolf.breedCount = tokens[13].toInt()
                        wolf.isAlpha = tokens[14].toBoolean()
                        engine.animals.add(wolf)
                    }
                    "SHEEP" -> {
                        val sheep = Sheep(
                            x = tokens[1].toFloat(),
                            y = tokens[2].toFloat(),
                            initEnergy = tokens[3].toInt(),
                            hungerThres = 500,
                            visionRange = tokens[5].toDouble(),
                            maxAgeLimit = tokens[6].toInt()
                        )
                        sheep.energy = tokens[7].toInt()
                        sheep.age = tokens[8].toInt()
                        sheep.angle = tokens[9].toDouble()
                        sheep.state = AnimalState.valueOf(tokens[10])
                        sheep.breedCount = tokens[11].toInt()
                        sheep.isAlpha = tokens[12].toBoolean()
                        engine.animals.add(sheep)
                    }
                }
            }

            engine.wolfCount = engine.animals.count { it is Wolf }
            engine.sheepCount = engine.animals.count { it is Sheep }
            engine.totalGrassHp = engine.grassZones.sumOf { it.hp }

            println("[SYSTEM] 수동 파일 불러오기 성공 완료")
        } catch (e: Exception) {
            println("[ERROR] 불러오기 실패: ${e.message}")
        }
    }
}