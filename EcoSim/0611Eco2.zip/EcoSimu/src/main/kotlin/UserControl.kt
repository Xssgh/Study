package eco

import kotlin.random.Random

// 4번 기능을 위해 DELETE(삭제)와 HEAL(수정) 모드 추가
enum class SpawnMode { WOLF, SHEEP, CAVE, DELETE, HEAL }

class UserControl(val engine: EcosystemEngine) {
    var currentMode: SpawnMode = SpawnMode.SHEEP

    fun handleMouseClick(clickX: Float, clickY: Float) {
        when (currentMode) {
            SpawnMode.WOLF -> {
                val assignedCave = engine.caves.minByOrNull { cave ->
                    val dx = (clickX - cave.x).toDouble()
                    val dy = (clickY - cave.y).toDouble()
                    dx * dx + dy * dy
                }
                val homeX = assignedCave?.x ?: clickX
                val homeY = assignedCave?.y ?: clickY

                engine.animals.add(
                    Wolf(
                        x = clickX, y = clickY, homeX = homeX, homeY = homeY,
                        initEnergy = Random.nextInt(1000, 1501),
                        hungerThres = Random.nextInt(400, 801),
                        visionRange = Random.nextDouble(180.0, 320.0),
                        maxAgeLimit = Random.nextInt(2500, 3501)
                    )
                )
            }
            SpawnMode.SHEEP -> {
                engine.animals.add(
                    Sheep(
                        x = clickX, y = clickY,
                        initEnergy = Random.nextInt(700, 1001),
                        hungerThres = Random.nextInt(500, 801),
                        visionRange = Random.nextDouble(150.0, 250.0),
                        maxAgeLimit = Random.nextInt(1500, 2501)
                    )
                )
            }
            SpawnMode.CAVE -> {
                val newIndex = engine.caves.size + 1
                engine.caves.add(Cave(x = clickX, y = clickY, name = "Cave-$newIndex"))
            }
            // [4번 기능 - 삭제] 클릭한 좌표 반경 20f 내의 가장 가까운 개체 삭제 (D)
            SpawnMode.DELETE -> {
                val target = findNearestAnimal(clickX, clickY)
                if (target != null) {
                    engine.animals.remove(target)
                    // 즉시 카운트 갱신
                    engine.wolfCount = engine.animals.count { it is Wolf }
                    engine.sheepCount = engine.animals.count { it is Sheep }
                    println("[SYSTEM] 개체가 사용자에 의해 삭제되었습니다.")
                }
            }
            // [4번 기능 - 수정] 클릭한 좌표 반경 20f 내의 가장 가까운 개체 상태 수정 (U)
            SpawnMode.HEAL -> {
                val target = findNearestAnimal(clickX, clickY)
                if (target != null) {
                    target.energy = target.maxEnergy // 에너지 풀 충전
                    target.age = 0                  // 나이 초기화 (젊음 유지)
                    println("[SYSTEM] 개체의 상태가 최대치로 수정 되었습니다.")
                }
            }
        }
    }

    // 클릭 위치에서 가장 가까운 동물을 찾는 헬퍼 함수 (클릭 반경 제약 20f)
    private fun findNearestAnimal(cx: Float, cy: Float): Animal? {
        return engine.animals.minByOrNull { animal ->
            val dx = (cx - animal.x).toDouble()
            val dy = (cy - animal.y).toDouble()
            dx * dx + dy * dy
        }?.let { nearest ->
            val dx = (cx - nearest.x).toDouble()
            val dy = (cy - nearest.y).toDouble()
            if (dx * dx + dy * dy < 20.0 * 20.0) nearest else null
        }
    }

    fun saveSimulation() {
        SaveManager.save(engine)
    }

    fun loadSimulation() {
        SaveManager.load(engine)
    }
}