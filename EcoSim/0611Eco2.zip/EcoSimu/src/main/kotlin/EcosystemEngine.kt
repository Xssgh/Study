package eco

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random
import java.util.concurrent.CopyOnWriteArrayList

class EcosystemEngine(val width: Float, val height: Float) {
    val animals = CopyOnWriteArrayList<Animal>()
    val grassZones = CopyOnWriteArrayList<GrassZone>()
    val caves = CopyOnWriteArrayList<Cave>()

    var wolfCount by mutableStateOf(0)
    var sheepCount by mutableStateOf(0)
    var totalGrassHp by mutableStateOf(0)

    var alphaWolfInfo by mutableStateOf("늑대 없음")
    var alphaSheepInfo by mutableStateOf("양 없음")

    fun initializeEcosystem() {
        repeat(SimConfig.GRASS_ZONE_COUNT) {
            val zone = GrassZone(0f, 0f)
            zone.respawn(width, height, caves)
            grassZones.add(zone)
        }

        repeat(10) {
            val assignedCave = caves.randomOrNull()
            val sx = assignedCave?.x ?: (Random.nextFloat() * width)
            val sy = assignedCave?.y ?: (Random.nextFloat() * height)
            animals.add(
                Wolf(
                    x = sx + Random.nextFloat() * 40f - 20f,
                    y = sy + Random.nextFloat() * 40f - 20f,
                    homeX = sx,
                    homeY = sy,
                    initEnergy = Random.nextInt(1000, 1501),
                    hungerThres = Random.nextInt(400, 801),
                    visionRange = Random.nextDouble(180.0, 320.0),
                    maxAgeLimit = Random.nextInt(2500, 3501)
                )
            )
        }

        repeat(50) {
            animals.add(
                Sheep(
                    x = Random.nextFloat() * (width - 100f) + 50f,
                    y = Random.nextFloat() * (height * 0.5f - 50f) + (height * 0.5f),
                    initEnergy = Random.nextInt(700, 1001),
                    hungerThres = Random.nextInt(500, 801),
                    visionRange = Random.nextDouble(150.0, 250.0),
                    maxAgeLimit = Random.nextInt(1500, 2501)
                )
            )
        }

        wolfCount = animals.count { it is Wolf }
        sheepCount = animals.count { it is Sheep }
        totalGrassHp = grassZones.sumOf { it.hp }
    }

    fun tick() {
        val currentAnimals = animals.toList()
        val wolves = currentAnimals.filterIsInstance<Wolf>()
        val sheeps = currentAnimals.filterIsInstance<Sheep>()

        val deadAnimals = mutableSetOf<Animal>()
        val newborns = mutableListOf<Animal>()

        finalWolvesAlphaSetup(wolves)

        val topLeaders = sheeps
            .sortedWith(compareByDescending<Sheep> { it.maxAge }.thenByDescending { it.energy })
            .take(4)

        sheeps.forEach { it.isAlpha = false }
        topLeaders.forEach { it.isAlpha = true }

        val followerCounts = mutableMapOf<Sheep, Int>()
        topLeaders.forEach { followerCounts[it] = 0 }

        // [개선 ①] 특정 양 한 마리를 타겟팅하고 있는 늑대의 수를 카운트하는 맵 (분산 사냥용)
        val sheepTargeterCounts = mutableMapOf<Sheep, Int>()
        sheeps.forEach { sheepTargeterCounts[it] = 0 }

        var currentWolfCount = 0
        var currentSheepCount = 0

        for (current in currentAnimals) {
            if (deadAnimals.contains(current)) continue

            current.age += 1
            if (current.age >= current.maxAge) {
                deadAnimals.add(current)
                continue
            }

            current.energy -= current.energyLossRate
            if (current.energy <= 0) {
                deadAnimals.add(current)
                continue
            }

            if (current is Wolf) {
                var targetSheep: Sheep? = null
                var desiredAngle = current.angle // 부드러운 회전을 유도할 최종 목표 각도 변수

                // [개선 ②] 배고프거나, 복귀 중(WANDER)이라도 바로 앞 눈앞에 사냥감이 있으면 추적 (기회주의적 사냥)
                val shouldHunt = current.isHungry() || current.state == AnimalState.WANDER

                if (shouldHunt) {
                    var minSqDist = current.vision * current.vision

                    // 만약 배고픈 상태가 아니라 복귀 중 눈앞의 사냥이라면, 시야 범위를 절반으로 좁혀서 기습 판단
                    if (!current.isHungry()) {
                        minSqDist = (current.vision * 0.5) * (current.vision * 0.5)
                    }

                    for (sheep in sheeps) {
                        if (deadAnimals.contains(sheep)) continue

                        // [개선 ① 적용] 이미 다른 늑대 2마리 이상이 쫓고 있는 양은 우선순위에서 배제하여 늑대 분산 유도
                        val currentTargeters = sheepTargeterCounts[sheep] ?: 0
                        if (currentTargeters >= 2 && current.isHungry()) continue

                        val dx = (current.x - sheep.x).toDouble()
                        val dy = (current.y - sheep.y).toDouble()
                        val sqDist = dx * dx + dy * dy

                        if (sqDist < minSqDist) {
                            minSqDist = sqDist
                            targetSheep = sheep
                        }
                    }
                }

                if (targetSheep != null) {
                    current.state = AnimalState.CHASE
                    // 타겟 양의 추적자 수 카운트 증가
                    sheepTargeterCounts[targetSheep] = (sheepTargeterCounts[targetSheep] ?: 0) + 1

                    desiredAngle = atan2((targetSheep.y - current.y).toDouble(), (targetSheep.x - current.x).toDouble())

                    val dx = (current.x - targetSheep.x).toDouble()
                    val dy = (current.y - targetSheep.y).toDouble()
                    if ((dx * dx + dy * dy) < (8.0 * 8.0)) {
                        deadAnimals.add(targetSheep)
                        current.energy = current.maxEnergy
                    }
                } else {
                    current.state = AnimalState.WANDER

                    val dxHome = (current.x - current.homeX).toDouble()
                    val dyHome = (current.y - current.homeY).toDouble()
                    val sqDistToHome = dxHome * dxHome + dyHome * dyHome

                    if (sqDistToHome > (150.0 * 150.0)) {
                        desiredAngle = atan2((current.homeY - current.y).toDouble(), (current.homeX - current.x).toDouble())
                    } else {
                        // 동굴 근처에서 특별한 타겟이 없으면 자연스럽게 꼬리를 물듯 약간의 무작위 배회 각도 추가
                        if (Random.nextFloat() < 0.08f) {
                            desiredAngle += Random.nextDouble(-0.4, 0.4)
                        }
                    }

                    if (current.energy >= SimConfig.WOLF_BREED_ENERGY && sqDistToHome < (100.0 * 100.0) && Random.nextFloat() < 0.05f) {
                        current.energy -= 600
                        current.breedCount += 1
                        newborns.add(
                            Wolf(
                                x = current.x + Random.nextFloat() * 20f - 10f,
                                y = current.y + Random.nextFloat() * 20f - 10f,
                                homeX = current.homeX,
                                homeY = current.homeY,
                                initEnergy = 1000,
                                hungerThres = Random.nextInt(400, 801),
                                visionRange = current.vision,
                                maxAgeLimit = Random.nextInt(2500, 3501)
                            )
                        )
                    }
                }

                // [개선 ③] 관성 제어 알고리즘 적용 (칼같이 꺾이지 않고 서서히 회전하도록 보간 처리)
                val angleDiff = desiredAngle - current.angle
                // 각도 차이를 -PI ~ PI 범위로 정규화하여 가장 빠른 회전 방향 계산
                val shortAngleDiff = atan2(sin(angleDiff), cos(angleDiff))

                // 한 틱당 최대 회전각을 제한 (0.15 라디안 약 8.5도씩 부드럽게 대가리를 돌림)
                val maxRotation = 0.15
                current.angle += shortAngleDiff.coerceIn(-maxRotation, maxRotation)

                if (!deadAnimals.contains(current)) currentWolfCount++
            }

            else if (current is Sheep) {
                var threatWolf: Wolf? = null
                var minWolfSqDist = (current.vision * 0.6) * (current.vision * 0.6)

                for (wolf in wolves) {
                    val dx = (current.x - wolf.x).toDouble()
                    val dy = (current.y - wolf.y).toDouble()
                    val sqDist = dx * dx + dy * dy
                    if (sqDist < minWolfSqDist) {
                        minWolfSqDist = sqDist
                        threatWolf = wolf
                    }
                }

                if (threatWolf != null) {
                    current.state = AnimalState.FLEE
                    val fleeTargetAngle = atan2((threatWolf.y - current.y).toDouble(), (threatWolf.x - current.x).toDouble()) + Math.PI
                    current.angle = current.angle * 0.85 + fleeTargetAngle * 0.15
                } else {
                    var targetZone: GrassZone? = null
                    if (current.isHungry()) {
                        var minZoneSqDist = current.vision * current.vision
                        for (zone in grassZones) {
                            if (zone.hp <= 0) continue
                            val dx = (current.x - zone.x).toDouble()
                            val dy = (current.y - zone.y).toDouble()
                            val sqDist = dx * dx + dy * dy
                            if (sqDist < minZoneSqDist) {
                                minZoneSqDist = sqDist
                                targetZone = zone
                            }
                        }
                    }

                    if (targetZone != null) {
                        current.state = AnimalState.CHASE
                        current.angle = atan2((targetZone.y - current.y).toDouble(), (targetZone.x - current.x).toDouble())

                        val dx = (current.x - targetZone.x).toDouble()
                        val dy = (current.y - targetZone.y).toDouble()
                        val limitDist = targetZone.radius + 4f
                        if ((dx * dx + dy * dy) < (limitDist * limitDist)) {
                            if (targetZone.hp > 0) {
                                targetZone.hp -= SimConfig.GRASS_EAT_AMOUNT
                                current.energy = (current.energy + 40).coerceAtMost(current.maxEnergy)
                            }
                        }
                    } else {
                        current.state = AnimalState.WANDER

                        if (current.isAlpha) {
                            if (Random.nextFloat() < 0.15f) {
                                current.angle += Random.nextDouble(-0.5, 0.5)
                            }
                        } else {
                            val visibleAlpha = topLeaders.filter { leader ->
                                val dx = (current.x - leader.x).toDouble()
                                val dy = (current.y - leader.y).toDouble()
                                (dx * dx + dy * dy) < (current.vision * current.vision)
                            }.minByOrNull { leader ->
                                val dx = (current.x - leader.x).toDouble()
                                val dy = (current.y - leader.y).toDouble()
                                dx * dx + dy * dy
                            }

                            if (visibleAlpha != null) {
                                val currentFollowers = followerCounts[visibleAlpha] ?: 0
                                if (currentFollowers < 20) {
                                    followerCounts[visibleAlpha] = currentFollowers + 1

                                    val dx = (visibleAlpha.x - current.x).toDouble()
                                    val dy = (visibleAlpha.y - current.y).toDouble()
                                    val sqDist = dx * dx + dy * dy

                                    if (sqDist < 40.0 * 40.0) {
                                        if (Random.nextFloat() < 0.2f) {
                                            current.angle = atan2(dy, dx) + (Math.PI / 2) + Random.nextDouble(-0.3, 0.3)
                                        }
                                    } else {
                                        current.angle = atan2(dy, dx)
                                    }
                                } else {
                                    if (Random.nextFloat() < 0.2f) {
                                        current.angle = atan2((visibleAlpha.y - current.y).toDouble(), (visibleAlpha.x - current.x).toDouble()) + Math.PI
                                    } else if (Random.nextFloat() < 0.15f) {
                                        current.angle += Random.nextDouble(-0.7, 0.7)
                                    }
                                }
                            } else {
                                if (Random.nextFloat() < 0.15f) {
                                    current.angle += Random.nextDouble(-0.5, 0.5)
                                }
                            }
                        }

                        if (current.energy >= SimConfig.SHEEP_BREED_ENERGY && Random.nextFloat() < 0.02f) {
                            current.energy -= 500
                            current.breedCount += 1
                            newborns.add(
                                Sheep(
                                    x = current.x + Random.nextFloat() * 30f - 15f,
                                    y = current.y + Random.nextFloat() * 30f - 15f,
                                    initEnergy = 700,
                                    hungerThres = Random.nextInt(500, 801),
                                    visionRange = current.vision,
                                    maxAgeLimit = Random.nextInt(1500, 2501)
                                )
                            )
                        }
                    }
                }
                if (!deadAnimals.contains(current)) currentSheepCount++
            }

            val currentSpeed = when (current.state) {
                AnimalState.CHASE -> current.speed * 1.1f
                AnimalState.FLEE -> current.speed * 1.0f
                AnimalState.WANDER -> current.speed * 0.5f
            }

            current.x += (cos(current.angle) * currentSpeed).toFloat()
            current.y += (sin(current.angle) * currentSpeed).toFloat()
            current.checkBounds(width, height)
        }

        totalGrassHp = processGrassZones()

        if (deadAnimals.isNotEmpty()) animals.removeAll(deadAnimals)
        if (newborns.isNotEmpty()) animals.addAll(newborns)

        val finalSheeps = animals.filterIsInstance<Sheep>()
        wolfCount = animals.count { it is Wolf }
        sheepCount = finalSheeps.size

        val displayAlphaSheep = topLeaders.firstOrNull { finalSheeps.contains(it) }
        if (displayAlphaSheep != null) {
            val totalFollowers = followerCounts[displayAlphaSheep] ?: 0
            alphaSheepInfo = "알파 양 - 번식: ${displayAlphaSheep.breedCount}회, 에너지: ${displayAlphaSheep.energy}/${displayAlphaSheep.maxEnergy}, 나이: ${displayAlphaSheep.age}/${displayAlphaSheep.maxAge}, 추종 무리: ${totalFollowers}마리"
        } else {
            alphaSheepInfo = "양 없음"
        }
    }

    private fun finalWolvesAlphaSetup(wolves: List<Wolf>) {
        wolves.forEach { it.isAlpha = false }
        val alphaWolf = wolves.maxWithOrNull(
            compareBy<Wolf> { it.breedCount }.thenBy { it.energy.toFloat() / it.maxEnergy.toFloat() }
        )
        if (alphaWolf != null) {
            alphaWolf.isAlpha = true
            alphaWolfInfo = "알파 늑대 - 번식: ${alphaWolf.breedCount}회, 에너지: ${alphaWolf.energy}/${alphaWolf.maxEnergy}, 나이: ${alphaWolf.age}/${alphaWolf.maxAge}, 속도: ${alphaWolf.speed}, 시야: ${alphaWolf.vision.toInt()}"
        } else {
            alphaWolfInfo = "늑대 없음"
        }
    }

    private fun processGrassZones(): Int {
        val deadZones = mutableListOf<GrassZone>()
        val newZones = mutableListOf<GrassZone>()
        var accumulator = 0

        for (zone in grassZones) {
            if (zone.hp <= 0) {
                deadZones.add(zone)
                continue
            }
            if (zone.hp < zone.maxHp && Random.nextInt(100) < 15) {
                zone.hp += 1
            }
            if (zone.hp >= zone.maxHp) {
                zone.growth += 1
                if (zone.growth >= SimConfig.GRASS_MAX_GROWTH) {
                    zone.growth = 0
                    if ((grassZones.size + newZones.size) < SimConfig.GRASS_MAX_ZONES_LIMIT) {
                        val (newX, newY) = zone.calculateSpreadLocation(width, height)
                        val isNearCave = caves.any { cave ->
                            val dx = (newX - cave.x).toDouble()
                            val dy = (newY - cave.y).toDouble()
                            (dx * dx + dy * dy) < (150.0 * 150.0)
                        }
                        if (!isNearCave) {
                            newZones.add(GrassZone(x = newX, y = newY, hp = SimConfig.GRASS_ZONE_MAX_HP / 2))
                        }
                    }
                }
            }
            accumulator += zone.hp
        }

        if (deadZones.isNotEmpty()) grassZones.removeAll(deadZones)
        if (newZones.isNotEmpty()) grassZones.addAll(newZones)

        if (grassZones.isEmpty()) {
            val emergencyZone = GrassZone(0f, 0f)
            var valid = false
            while (!valid) {
                val rx = Random.nextFloat() * (width - 100f) + 50f
                val ry = Random.nextFloat() * (height * 0.5f - 50f) + (height * 0.5f)
                val nearCave = caves.any { cave ->
                    val dx = (rx - cave.x).toDouble()
                    val dy = (ry - cave.y).toDouble()
                    (dx * dx + dy * dy) < (150.0 * 150.0)
                }
                if (!nearCave) {
                    emergencyZone.x = rx
                    emergencyZone.y = ry
                    valid = true
                }
            }
            grassZones.add(emergencyZone)
            accumulator += emergencyZone.hp
        }
        return accumulator
    }
}