package eco

import java.io.File
import java.io.BufferedWriter
import java.io.BufferedReader

object SaveManager {
    private val file = File("savegame.txt")

    // 1. 저장 로직: BufferedWriter와 use를 사용하여 자원 자동 해제 및 컬렉션 확장함수 조작
    fun save(engine: EcosystemEngine) {
        try {
            // [조건 ④ 만족] BufferedWriter 생성 후 use를 사용하여 파일 출력 스트림을 안전하게 닫음
            file.bufferedWriter().use { writer ->

                // [조건 ② 만족] map과 forEach 확장함수를 연쇄(Chaining)하여 의미 있게 데이터 가공
                // 동굴 데이터를 문자열 리스트로 변환 후 한 줄씩 기록
                engine.caves
                    .map { "CAVE|${it.x}|${it.y}|${it.radius}|${it.name}" }
                    .forEach { line -> writer.write(line + "\n") }

                // 풀 구역 데이터를 문자열 리스트로 변환 후 한 줄씩 기록
                engine.grassZones
                    .map { "GRASS|${it.x}|${it.y}|${it.radius}|${it.maxHp}|${it.hp}|${it.growth}" }
                    .forEach { line -> writer.write(line + "\n") }

                // 동물 데이터를 Wolf와 Sheep으로 필터링 및 변환하여 기록
                engine.animals.forEach { animal ->
                    if (animal is Wolf) {
                        writer.write("WOLF|${animal.x}|${animal.y}|${animal.homeX}|${animal.homeY}|${animal.maxEnergy}|${animal.speed}|${animal.vision}|${animal.maxAge}|${animal.energy}|${animal.age}|${animal.angle}|${animal.state}|${animal.breedCount}|${animal.isAlpha}\n")
                    } else if (animal is Sheep) {
                        writer.write("SHEEP|${animal.x}|${animal.y}|${animal.maxEnergy}|${animal.speed}|${animal.vision}|${animal.maxAge}|${animal.energy}|${animal.age}|${animal.angle}|${animal.state}|${animal.breedCount}|${animal.isAlpha}\n")
                    }
                }
            }
            println("[SYSTEM] 수동 파일 저장 성공: savegame.txt")
        } catch (e: Exception) {
            println("[ERROR] 저장 실패: ${e.message}")
        }
    }

    // 2. 불러오기 로직: BufferedReader와 use를 사용하여 자원 자동 해제
    fun load(engine: EcosystemEngine) {
        try {
            if (!file.exists()) {
                println("[ERROR] 저장된 파일이 없습니다.")
                return
            }

            engine.caves.clear()
            engine.grassZones.clear()
            engine.animals.clear()

            // [조건 ④ 만족] BufferedReader 생성 후 use를 사용하여 파일 입력 스트림을 안전하게 닫음
            file.bufferedReader().use { reader ->
                reader.forEachLine { line ->
                    val tokens = line.split("|")
                    if (tokens.isEmpty() || tokens[0].isBlank()) return@forEachLine

                    when (tokens[0]) {
                        "CAVE" -> {
                            val cave = Cave(
                                x = tokens[1].toFloat(),
                                y = tokens[2].toFloat(),
                                radius = tokens[3].toFloat(),
                                name = tokens[4]
                            )
                            engine.caves.add(cave)
                        }
                        "GRASS" -> {
                            val zone = GrassZone(
                                x = tokens[1].toFloat(),
                                y = tokens[2].toFloat(),
                                radius = tokens[3].toFloat(),
                                maxHp = tokens[4].toInt(),
                                hp = tokens[5].toInt()
                            )
                            zone.growth = tokens[6].toInt()
                            engine.grassZones.add(zone)
                        }
                        "WOLF" -> {
                            val wolf = Wolf(
                                x = tokens[1].toFloat(),
                                y = tokens[2].toFloat(),
                                homeX = tokens[3].toFloat(),
                                homeY = tokens[4].toFloat(),
                                initEnergy = tokens[5].toInt(),
                                hungerThres = 400,
                                visionRange = tokens[7].toDouble(),
                                maxAgeLimit = tokens[8].toInt()
                            )
                            wolf.energy = tokens[9].toInt()
                            wolf.age = tokens[10].toInt()
                            wolf.angle = tokens[11].toDouble()
                            wolf.state = AnimalState.valueOf(tokens[12])
                            wolf.breedCount = tokens[13].toInt()
                            wolf.isAlpha = tokens[14].toBoolean()
                            engine.animals.add(wolf)
                        }
                        "SHEEP" -> {
                            val sheep = Sheep(
                                x = tokens[1].toFloat(),
                                y = tokens[2].toFloat(),
                                initEnergy = tokens[3].toInt(),
                                hungerThres = 500,
                                visionRange = tokens[5].toDouble(),
                                maxAgeLimit = tokens[6].toInt()
                            )
                            sheep.energy = tokens[7].toInt()
                            sheep.age = tokens[8].toInt()
                            sheep.angle = tokens[9].toDouble()
                            sheep.state = AnimalState.valueOf(tokens[10])
                            sheep.breedCount = tokens[11].toInt()
                            sheep.isAlpha = tokens[12].toBoolean()
                            engine.animals.add(sheep)
                        }
                    }
                }
            }

            // [조건 ② 만족] count, sumOf 컬렉션 확장함수를 활용한 엔진 상태 변수 갱신
            engine.wolfCount = engine.animals.count { it is Wolf }
            engine.sheepCount = engine.animals.count { it is Sheep }
            engine.totalGrassHp = engine.grassZones.sumOf { it.hp }

            println("[SYSTEM] 수동 파일 불러오기 성공 완료")
        } catch (e: Exception) {
            println("[ERROR] 불러오기 실패: ${e.message}")
        }
    }
}