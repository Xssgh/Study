package eco

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.min
import kotlin.random.Random
import java.util.concurrent.CopyOnWriteArrayList

class EcosystemEngine(val width: Float, val height: Float) {
    val animals = CopyOnWriteArrayList<Animal>()
    val grassZones = CopyOnWriteArrayList<GrassZone>()
    val caves = CopyOnWriteArrayList<Cave>()

    var wolfCount by mutableStateOf(0)
    var sheepCount by mutableStateOf(0)
    var totalGrassHp by mutableStateOf(0)

    fun initializeEcosystem() {
        caves.add(Cave(250f, 150f))
        caves.add(Cave(750f, 150f))

        repeat(SimConfig.GRASS_ZONE_COUNT) {
            val zone = GrassZone(0f, 0f)
            zone.respawn(width, height, caves)
            grassZones.add(zone)
        }

        repeat(10) {
            val assignedCave = caves.random()
            val randomEnergy = Random.nextInt(1000, 1501)
            val randomThreshold = Random.nextInt(400, 801)
            val randomVision = Random.nextDouble(180.0, 320.0)
            val randomMaxAge = Random.nextInt(2500, 3501)

            animals.add(
                Wolf(
                    x = assignedCave.x + Random.nextFloat() * 40f - 20f,
                    y = assignedCave.y + Random.nextFloat() * 40f - 20f,
                    homeX = assignedCave.x,
                    homeY = assignedCave.y,
                    initEnergy = randomEnergy,
                    hungerThres = randomThreshold,
                    visionRange = randomVision,
                    maxAgeLimit = randomMaxAge
                )
            )
        }

        repeat(50) {
            val randomEnergy = Random.nextInt(700, 1001)
            val randomThreshold = Random.nextInt(500, 801)
            val randomVision = Random.nextDouble(150.0, 250.0)
            val randomMaxAge = Random.nextInt(1500, 2501)

            animals.add(
                Sheep(
                    x = Random.nextFloat() * (width - 100f) + 50f,
                    y = Random.nextFloat() * (height * 0.5f - 50f) + (height * 0.5f),
                    initEnergy = randomEnergy,
                    hungerThres = randomThreshold,
                    visionRange = randomVision,
                    maxAgeLimit = randomMaxAge
                )
            )
        }

        var initWolves = 0
        var initSheep = 0
        for (a in animals) {
            if (a is Wolf) initWolves++ else if (a is Sheep) initSheep++
        }
        wolfCount = initWolves
        sheepCount = initSheep
        totalGrassHp = grassZones.sumOf { it.hp }
    }

    fun tick() {
        val currentAnimals = animals.toList()
        val wolves = currentAnimals.filterIsInstance<Wolf>()
        val sheeps = currentAnimals.filterIsInstance<Sheep>()

        val deadAnimals = mutableSetOf<Animal>()
        val newborns = mutableListOf<Animal>()

        var currentWolfCount = 0
        var currentSheepCount = 0

        // 1. 동물 상태 업데이트 및 이동 로직 루프
        for (current in currentAnimals) {
            if (deadAnimals.contains(current)) continue

            current.age += 1
            if (current.age >= current.maxAge) {
                deadAnimals.add(current)
                continue
            }

            current.energy -= current.energyLossRate
            if (current.energy <= 0) {
                deadAnimals.add(current)
                continue
            }

            if (current is Wolf) {
                var targetSheep: Sheep? = null
                if (current.isHungry()) {
                    var minSqDist = current.vision * current.vision
                    for (sheep in sheeps) {
                        if (deadAnimals.contains(sheep)) continue
                        val dx = (current.x - sheep.x).toDouble()
                        val dy = (current.y - sheep.y).toDouble()
                        val sqDist = dx * dx + dy * dy
                        if (sqDist < minSqDist) {
                            minSqDist = sqDist
                            targetSheep = sheep
                        }
                    }
                }

                if (targetSheep != null) {
                    current.state = AnimalState.CHASE
                    current.angle = atan2((targetSheep.y - current.y).toDouble(), (targetSheep.x - current.x).toDouble())

                    val dx = (current.x - targetSheep.x).toDouble()
                    val dy = (current.y - targetSheep.y).toDouble()
                    if ((dx * dx + dy * dy) < (8.0 * 8.0)) {
                        deadAnimals.add(targetSheep)
                        current.energy = current.maxEnergy
                    }
                } else {
                    current.state = AnimalState.WANDER

                    val dxHome = (current.x - current.homeX).toDouble()
                    val dyHome = (current.y - current.homeY).toDouble()
                    val sqDistToHome = dxHome * dxHome + dyHome * dyHome

                    if (sqDistToHome > (150.0 * 150.0)) {
                        current.angle = atan2((current.homeY - current.y).toDouble(), (current.homeX - current.x).toDouble())
                    }

                    if (current.energy >= SimConfig.WOLF_BREED_ENERGY && sqDistToHome < (100.0 * 100.0) && Random.nextFloat() < 0.05f) {
                        current.energy -= 600
                        newborns.add(
                            Wolf(
                                x = current.x + Random.nextFloat() * 20f - 10f,
                                y = current.y + Random.nextFloat() * 20f - 10f,
                                homeX = current.homeX,
                                homeY = current.homeY,
                                initEnergy = 1000,
                                hungerThres = Random.nextInt(400, 801),
                                visionRange = current.vision,
                                maxAgeLimit = Random.nextInt(2500, 3501)
                            )
                        )
                    }
                }
                if (!deadAnimals.contains(current)) currentWolfCount++
            }

            else if (current is Sheep) {
                var threatWolf: Wolf? = null
                var minWolfSqDist = (current.vision * 0.6) * (current.vision * 0.6)

                for (wolf in wolves) {
                    val dx = (current.x - wolf.x).toDouble()
                    val dy = (current.y - wolf.y).toDouble()
                    val sqDist = dx * dx + dy * dy
                    if (sqDist < minWolfSqDist) {
                        minWolfSqDist = sqDist
                        threatWolf = wolf
                    }
                }

                if (threatWolf != null) {
                    current.state = AnimalState.FLEE
                    current.angle = atan2((threatWolf.y - current.y).toDouble(), (threatWolf.x - current.x).toDouble()) + Math.PI
                } else {
                    var targetZone: GrassZone? = null
                    if (current.isHungry()) {
                        var minZoneSqDist = current.vision * current.vision
                        for (zone in grassZones) {
                            if (zone.hp <= 0) continue
                            val dx = (current.x - zone.x).toDouble()
                            val dy = (current.y - zone.y).toDouble()
                            val sqDist = dx * dx + dy * dy
                            if (sqDist < minZoneSqDist) {
                                minZoneSqDist = sqDist
                                targetZone = zone
                            }
                        }
                    }

                    if (targetZone != null) {
                        current.state = AnimalState.CHASE
                        current.angle = atan2((targetZone.y - current.y).toDouble(), (targetZone.x - current.x).toDouble())

                        val dx = (current.x - targetZone.x).toDouble()
                        val dy = (current.y - targetZone.y).toDouble()
                        val limitDist = targetZone.radius + 4f
                        if ((dx * dx + dy * dy) < (limitDist * limitDist)) {
                            if (targetZone.hp > 0) {
                                targetZone.hp -= SimConfig.GRASS_EAT_AMOUNT
                                current.energy = (current.energy + 40).coerceAtMost(current.maxEnergy)
                            }
                        }
                    } else {
                        current.state = AnimalState.WANDER

                        if (current.energy >= SimConfig.SHEEP_BREED_ENERGY && Random.nextFloat() < 0.02f) {
                            current.energy -= 500
                            newborns.add(
                                Sheep(
                                    x = current.x + Random.nextFloat() * 30f - 15f,
                                    y = current.y + Random.nextFloat() * 30f - 15f,
                                    initEnergy = 700,
                                    hungerThres = Random.nextInt(500, 801),
                                    visionRange = current.vision,
                                    maxAgeLimit = Random.nextInt(1500, 2501)
                                )
                            )
                        }
                    }
                }
                if (!deadAnimals.contains(current)) currentSheepCount++
            }

            if (current.state == AnimalState.WANDER && Random.nextFloat() < 0.12f) {
                current.angle += Random.nextDouble(-0.5, 0.5)
            }

            val currentSpeed = when (current.state) {
                AnimalState.CHASE -> current.speed * 1.1f
                AnimalState.FLEE -> current.speed * 1.0f
                AnimalState.WANDER -> current.speed * 0.5f
            }

            current.x += (cos(current.angle) * currentSpeed).toFloat()
            current.y += (sin(current.angle) * currentSpeed).toFloat()
            current.checkBounds(width, height)
        }

        // 💡 2. [변경] 풀 군락 성장, 확산 및 소멸 시스템 연산
        val deadZones = mutableListOf<GrassZone>()
        val newZones = mutableListOf<GrassZone>()
        var totalHpAccumulator = 0

        for (zone in grassZones) {
            if (zone.hp <= 0) {
                // 완전히 다 뜯어먹힌 풀 군락은 텔레포트하지 않고 소멸(삭제 리스트 추가)
                deadZones.add(zone)
                continue
            }

            // 체력이 깎여있다면 서서히 자연 회복 (틱당 15% 확률)
            if (zone.hp < zone.maxHp && Random.nextInt(100) < 15) {
                zone.hp += 1
            }

            // 💡 군락 체력이 가득 차 있어야만 내부 성장도(growth)가 누적됨
            if (zone.hp >= zone.maxHp) {
                zone.growth += 1

                // 성장도가 임계값에 도달하면 주변 영토로 씨앗 확산
                if (zone.growth >= SimConfig.GRASS_MAX_GROWTH) {
                    zone.growth = 0 // 성장도 초기화

                    // 화면 내 풀 구역 총합이 상한선 미만일 때만 새로운 자식 군락을 생성
                    if ((grassZones.size + newZones.size) < SimConfig.GRASS_MAX_ZONES_LIMIT) {
                        val (newX, newY) = zone.calculateSpreadLocation(width, height)

                        // 동굴 근처인지 검증
                        val isNearCave = caves.any { cave ->
                            val dx = (newX - cave.x).toDouble()
                            val dy = (newY - cave.y).toDouble()
                            (dx * dx + dy * dy) < (150.0 * 150.0)
                        }

                        if (!isNearCave) {
                            // 신생 군락은 부모의 절반 체력 에너지 상태로 약하게 시작
                            newZones.add(GrassZone(x = newX, y = newY, hp = SimConfig.GRASS_ZONE_MAX_HP / 2))
                        }
                    }
                }
            }
            totalHpAccumulator += zone.hp
        }

        // 틱 정리: 완전히 소멸한 풀 구역 제외 및 새로운 번식 구역 투입
        if (deadZones.isNotEmpty()) grassZones.removeAll(deadZones)
        if (newZones.isNotEmpty()) grassZones.addAll(newZones)

        // 💡 [안전장치] 양들의 폭식으로 맵의 풀 군락이 전멸했을 경우 최소 1개의 생존 안전망 자동 수급
        if (grassZones.isEmpty()) {
            val emergencyZone = GrassZone(0f, 0f)
            var valid = false
            while (!valid) {
                val rx = Random.nextFloat() * (width - 100f) + 50f
                val ry = Random.nextFloat() * (height * 0.5f - 50f) + (height * 0.5f)
                val nearCave = caves.any { cave ->
                    val dx = (rx - cave.x).toDouble()
                    val dy = (ry - cave.y).toDouble()
                    (dx * dx + dy * dy) < (150.0 * 150.0)
                }
                if (!nearCave) {
                    emergencyZone.x = rx
                    emergencyZone.y = ry
                    valid = true
                }
            }
            grassZones.add(emergencyZone)
            totalHpAccumulator += emergencyZone.hp
        }

        // 3. 동물 객체 소멸 및 번식 동기화
// EcosystemEngine.kt 맨 아래쪽 수정본

        if (deadAnimals.isNotEmpty()) animals.removeAll(deadAnimals)

// 💡 newbornAnimals를 newborns로 수정
        if (newborns.isNotEmpty()) {
            animals.addAll(newborns)
            newborns.forEach {
                if (it is Wolf) currentWolfCount++ else if (it is Sheep) currentSheepCount++
            }
        }

        wolfCount = currentWolfCount
        sheepCount = currentSheepCount
        totalGrassHp = totalHpAccumulator

    }
}