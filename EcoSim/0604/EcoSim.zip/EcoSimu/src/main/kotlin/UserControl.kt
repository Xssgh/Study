package eco

import kotlin.random.Random

enum class SpawnMode { WOLF, SHEEP, CAVE }

class UserControl(private val engine: EcosystemEngine) {
    var currentMode: SpawnMode = SpawnMode.SHEEP

    fun handleMouseClick(clickX: Float, clickY: Float) {
        when (currentMode) {
            SpawnMode.WOLF -> {
                // 💡 [변경] 리스트에서 랜덤으로 고르지 않고, 클릭한 좌표와 가장 가까운 동굴을 탐색 (거리 제곱 비교)
                val assignedCave = engine.caves.minByOrNull { cave ->
                    val dx = (clickX - cave.x).toDouble()
                    val dy = (clickY - cave.y).toDouble()
                    dx * dx + dy * dy
                }

                // 만약 맵에 동굴이 하나도 없다면 클릭한 위치를 임시 집으로 지정
                val homeX = assignedCave?.x ?: clickX
                val homeY = assignedCave?.y ?: clickY

                engine.animals.add(
                    Wolf(
                        x = clickX,
                        y = clickY,
                        homeX = homeX,
                        homeY = homeY,
                        initEnergy = Random.nextInt(1000, 1501),
                        hungerThres = Random.nextInt(400, 801),
                        visionRange = Random.nextDouble(180.0, 320.0),
                        maxAgeLimit = Random.nextInt(2500, 3501)
                    )
                )
            }
            SpawnMode.SHEEP -> {
                engine.animals.add(
                    Sheep(
                        x = clickX,
                        y = clickY,
                        initEnergy = Random.nextInt(700, 1001),
                        hungerThres = Random.nextInt(500, 801),
                        visionRange = Random.nextDouble(150.0, 250.0),
                        maxAgeLimit = Random.nextInt(1500, 2501)
                    )
                )
            }
            SpawnMode.CAVE -> {
                engine.caves.add(Cave(x = clickX, y = clickY))
            }
        }
    }
}