package eco

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Button
import androidx.compose.material.ButtonDefaults
import androidx.compose.material.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Window
import androidx.compose.ui.window.application
import kotlinx.coroutines.delay

fun main() = application {
    Window(
        onCloseRequest = ::exitApplication,
        title = "EcoSimu - 영역 기반 풀(체력형) 교체 버전"
    ) {

        val engine = remember { EcosystemEngine(1000f, 800f) }
        val userControl = remember { UserControl(engine) }

        var currentModeState by remember { mutableStateOf(userControl.currentMode) }
        var tickTrigger by remember { mutableStateOf(0) }

        LaunchedEffect(Unit) {
            // 💡 구구절절 길었던 스폰 코드를 엔진 내부 캡슐화 함수 한 줄로 퉁침
            engine.initializeEcosystem()

            while (true) {
                delay(60)
                engine.tick()
                tickTrigger++
            }
        }

        Box(modifier = Modifier.fillMaxSize()) {
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(Unit) {
                        detectTapGestures { offset ->
                            userControl.handleMouseClick(offset.x, offset.y)
                        }
                    }
            ) {
                val dummy = tickTrigger

                // 1. 동굴 렌더링
                engine.caves.forEach { cave ->
                    drawRect(
                        color = Color.Gray,
                        topLeft = Offset(cave.x - (cave.radius / 2), cave.y - (cave.radius / 2)),
                        size = Size(cave.radius, cave.radius)
                    )
                }

                // 2. 풀 군락 영역 렌더링
                engine.grassZones.forEach { zone ->
                    if (zone.hp > 0) {
                        val alphaRatio = zone.hp.toFloat() / zone.maxHp.toFloat()
                        drawCircle(
                            color = Color(0xFF4CAF50).copy(alpha = alphaRatio * 0.4f),
                            radius = zone.radius,
                            center = Offset(zone.x, zone.y)
                        )
                        drawCircle(
                            color = Color(0xFF2E7D32).copy(alpha = alphaRatio),
                            radius = 2.5f,
                            center = Offset(zone.x, zone.y)
                        )
                    }
                }

                // 3. 야생 동물 렌더링
                engine.animals.forEach { animal ->
                    val color = if (animal is Wolf) Color(0xFFE53935) else Color(0xFF2196F3)
                    val radius = if (animal is Wolf) 5f else 3f

                    drawCircle(
                        color = color,
                        radius = radius,
                        center = Offset(animal.x, animal.y)
                    )
                }
            }

            // 좌측 상단: 개체수 정보창
            Column(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(16.dp)
                    .background(Color(0x99000000), shape = RoundedCornerShape(4.dp))
                    .padding(12.dp)
            ) {
                Text(text = "늑대 (Wolf) : ${engine.wolfCount} 마리", color = Color(0xFFFF5252))
                Text(text = "양 (Sheep) : ${engine.sheepCount} 마리", color = Color(0xFF448AFF))
                Text(text = "생태계 총 풀 체력 : ${engine.totalGrassHp} HP", color = Color(0xFF69F0AE))
            }

            // 화면 중간 하단: 컨트롤 패널 (스폰 모드 변경용)
            Row(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 24.dp)
                    .background(Color(0xCC000000), shape = RoundedCornerShape(8.dp))
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "스폰 모드 선택 :", color = Color.White)

                Button(
                    onClick = { userControl.currentMode = SpawnMode.SHEEP; currentModeState = SpawnMode.SHEEP },
                    colors = ButtonDefaults.buttonColors(backgroundColor = if(currentModeState == SpawnMode.SHEEP) Color(0xFF2196F3) else Color.Gray)
                ) {
                    Text("양", color = Color.White)
                }
                Button(
                    onClick = { userControl.currentMode = SpawnMode.WOLF; currentModeState = SpawnMode.WOLF },
                    colors = ButtonDefaults.buttonColors(backgroundColor = if(currentModeState == SpawnMode.WOLF) Color(0xFFE53935) else Color.Gray)
                ) {
                    Text("늑대", color = Color.White)
                }
                Button(
                    onClick = { userControl.currentMode = SpawnMode.CAVE; currentModeState = SpawnMode.CAVE },
                    colors = ButtonDefaults.buttonColors(backgroundColor = if(currentModeState == SpawnMode.CAVE) Color(0xFF757575) else Color.Gray)
                ) {
                    Text("동굴", color = Color.White)
                }
            }
        }
    }
}