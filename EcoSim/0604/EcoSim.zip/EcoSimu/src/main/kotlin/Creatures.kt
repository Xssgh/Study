package eco

import kotlin.random.Random

enum class AnimalState { WANDER, CHASE, FLEE }

object SimConfig {
    const val WOLF_MAX_ENERGY = 1500
    const val SHEEP_MAX_ENERGY = 1000
    const val WOLF_BREED_ENERGY = 1400
    const val SHEEP_BREED_ENERGY = 900

    // 풀 군락 관련 설정
    const val GRASS_ZONE_COUNT = 8       // 초기 생성할 풀 군락 개수
    const val GRASS_ZONE_RADIUS = 35f    // 풀 영역 반지름
    const val GRASS_ZONE_MAX_HP = 200    // 풀 군락 최대 체력
    const val GRASS_EAT_AMOUNT = 5       // 양이 한 틱에 뜯어먹는 풀 체력 양

    // 💡 풀 성장 및 확산 관련 상수 추가
    const val GRASS_MAX_GROWTH = 30     // 번식에 필요한 성장도 기준치
    const val GRASS_MAX_ZONES_LIMIT = 20 // 화면 내 풀 군락 최대 개수 제한 (성능 안전장치)
}

abstract class Animal(
    var x: Float,
    var y: Float,
    val type: String,
    var angle: Double = Random.nextDouble() * Math.PI * 2,
    val speed: Float,
    val maxEnergy: Int,
    var energy: Int,
    var state: AnimalState = AnimalState.WANDER,
    val energyLossRate: Int,
    val hungerThreshold: Int,
    val vision: Double,
    var age: Int = 0,
    val maxAge: Int
) {
    fun isHungry(): Boolean = this.energy <= this.hungerThreshold

    fun checkBounds(maxWidth: Float, maxHeight: Float) {
        if (x < 5f) { x = 5f; angle = Math.PI - angle }
        if (x > maxWidth - 5f) { x = maxWidth - 5f; angle = Math.PI - angle }
        if (y < 5f) { y = 5f; angle = -angle }
        if (y > maxHeight - 5f) { y = maxHeight - 5f; angle = -angle }

        val twoPi = Math.PI * 2
        angle = (angle % twoPi + twoPi) % twoPi
    }
}

class Wolf(
    x: Float, y: Float, val homeX: Float, val homeY: Float,
    initEnergy: Int, hungerThres: Int, visionRange: Double, maxAgeLimit: Int
) : Animal(
    x = x, y = y, type = "WOLF", speed = 4.5f,
    maxEnergy = SimConfig.WOLF_MAX_ENERGY, energy = initEnergy,
    energyLossRate = 2, hungerThreshold = hungerThres, vision = visionRange,
    maxAge = maxAgeLimit
)

class Sheep(
    x: Float, y: Float, initEnergy: Int, hungerThres: Int, visionRange: Double, maxAgeLimit: Int
) : Animal(
    x = x, y = y, type = "SHEEP", speed = 3.5f,
    maxEnergy = SimConfig.SHEEP_MAX_ENERGY, energy = initEnergy,
    energyLossRate = 1, hungerThreshold = hungerThres, vision = visionRange,
    maxAge = maxAgeLimit
)

class GrassZone(
    var x: Float,
    var y: Float,
    val radius: Float = SimConfig.GRASS_ZONE_RADIUS,
    var hp: Int = SimConfig.GRASS_ZONE_MAX_HP,
    val maxHp: Int = SimConfig.GRASS_ZONE_MAX_HP,
    var growth: Int = 0 // 💡 풀 군락 성장도 속성 추가
) {
    // 초기 배치용 안전 스폰 로직 (동굴 회피)
    fun respawn(maxWidth: Float, maxHeight: Float, caves: List<Cave>) {
        var validLocation = false
        var newX = 0f
        var newY = 0f

        while (!validLocation) {
            newX = Random.nextFloat() * (maxWidth - 100f) + 50f
            val minY = maxHeight * 0.5f
            newY = minY + (Random.nextFloat() * (maxHeight - minY - 50f))

            val isNearCave = caves.any { cave ->
                val dx = (newX - cave.x).toDouble()
                val dy = (newY - cave.y).toDouble()
                (dx * dx + dy * dy) < (180.0 * 180.0)
            }
            if (!isNearCave) validLocation = true
        }

        this.x = newX
        this.y = newY
        this.hp = this.maxHp
        this.growth = 0
    }

    // 💡 [추가] 성장 완료 시 주변 무작위 방향으로 자식 군락의 스폰 위치를 계산하는 함수
    fun calculateSpreadLocation(maxWidth: Float, maxHeight: Float): Pair<Float, Float> {
        val angle = Random.nextDouble() * Math.PI * 2
        // 군락 반지름의 약 2~4배 거리 범위 내로 확산 유도
        val distance = Random.nextFloat() * 70f + 70f

        val newX = (this.x + kotlin.math.cos(angle) * distance).toFloat().coerceIn(50f, maxWidth - 50f)
        val minY = maxHeight * 0.5f
        val newY = (this.y + kotlin.math.sin(angle) * distance).toFloat().coerceIn(minY, maxHeight - 50f)

        return Pair(newX, newY)
    }
}

data class Cave(val x: Float, val y: Float, val radius: Float = 40f)