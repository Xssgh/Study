package eco

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material.Button
import androidx.compose.material.ButtonDefaults
import androidx.compose.material.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Window
import androidx.compose.ui.window.application
import androidx.compose.ui.window.rememberWindowState
import kotlinx.coroutines.delay
import java.util.Scanner

fun main() = application {
    val scanner = Scanner(System.`in`)
    val alphaNumericRegex = Regex("^[a-zA-Z0-9 ]+$")

    fun getValidCaveName(prompt: String): String {
        while (true) {
            print(prompt)
            val input = scanner.nextLine().trim()

            if (input.isBlank()) {
                return "DefaultCave"
            }

            if (!input.matches(alphaNumericRegex)) {
                println("[ERROR] 한글이나 특수문자는 사용할 수 없습니다. 영문과 숫자만 사용해 주세요.")
                continue
            }
            return input
        }
    }

    println("=== 초기 동굴 이름 설정 (영문/숫자만 가능) ===")
    val cave1Name = getValidCaveName("첫 번째 동굴(좌측)의 이름을 입력하세요: ")
    val cave2Name = getValidCaveName("두 번째 동굴(우측)의 이름을 입력하세요: ")
    println("==============================================")

    val windowState = rememberWindowState(width = 1200.dp, height = 800.dp)

    Window(
        onCloseRequest = ::exitApplication,
        title = "Ecosystem Simulation",
        state = windowState
    ) {
        val engine = remember { EcosystemEngine(1000f, 700f) }
        val userControl = remember { UserControl(engine) }
        var tickTrigger by remember { mutableStateOf(0) }
        var showDetailedInfo by remember { mutableStateOf(false) }

        LaunchedEffect(Unit) {
            engine.caves.add(Cave(250f, 150f, name = cave1Name))
            engine.caves.add(Cave(750f, 150f, name = cave2Name))

            engine.initializeEcosystem()

            while (true) {
                delay(60)
                engine.tick()
                tickTrigger++
            }
        }

        Row(modifier = Modifier.fillMaxSize().background(Color(0xFF1E1E1E))) {
            Box(
                modifier = Modifier
                    .width(1000.dp)
                    .height(700.dp)
                    .background(Color(0xFF2D2D2D))
                    .pointerInput(Unit) {
                        detectTapGestures { offset ->
                            userControl.handleMouseClick(offset.x, offset.y)
                        }
                    }
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    tickTrigger.let { }

                    engine.grassZones.forEach { zone ->
                        if (zone.hp > 0) {
                            drawCircle(
                                color = Color(0x4000FF00),
                                radius = zone.radius,
                                center = Offset(zone.x, zone.y)
                            )
                            drawCircle(
                                color = Color(0xFF00FF00),
                                radius = 4f,
                                center = Offset(zone.x, zone.y)
                            )
                        }
                    }

                    engine.caves.forEach { cave ->
                        drawCircle(
                            color = Color(0xFF8B7A5E),
                            radius = cave.radius,
                            center = Offset(cave.x, cave.y)
                        )
                    }

                    engine.animals.forEach { animal ->
                        val color = when (animal) {
                            is Wolf -> if (animal.isAlpha) Color(0xFFFF5252) else Color(0xFFFF8A80)
                            is Sheep -> if (animal.isAlpha) Color(0xFF448AFF) else Color(0xFFB2FF59)
                            else -> Color.White
                        }
                        drawCircle(
                            color = color,
                            radius = if (animal.isAlpha) 9f else 6f,
                            center = Offset(animal.x, animal.y)
                        )
                    }
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxHeight()
                    .weight(1f)
                    .background(Color(0xFF252526))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF333333))
                        .padding(8.dp)
                        .clickable { showDetailedInfo = !showDetailedInfo }
                ) {
                    if (!showDetailedInfo) {
                        Text(text = "늑대 (Wolf) : ${engine.wolfCount} 마리 [상세 정보 클릭]", color = Color(0xFFFF5252))
                        Text(text = "양 (Sheep) : ${engine.sheepCount} 마리", color = Color(0xFF448AFF))
                        Text(text = "생태계 총 풀 체력 : ${engine.totalGrassHp} HP", color = Color(0xFF69F0AE))
                    } else {
                        Text(text = "[알파 개체 정보 - 복귀 클릭]", color = Color.White)
                        Text(text = engine.alphaWolfInfo, color = Color(0xFFFF9800))
                        Text(text = engine.alphaSheepInfo, color = Color(0xFF9C27B0))
                    }
                }

                Text(text = "스폰 모드 선택", color = Color.White)

                Button(
                    onClick = { userControl.currentMode = SpawnMode.SHEEP },
                    colors = ButtonDefaults.buttonColors(
                        backgroundColor = if (userControl.currentMode == SpawnMode.SHEEP) Color(0xFF448AFF) else Color(0xFF444444)
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("양 (Sheep) 스폰", color = Color.White)
                }

                Button(
                    onClick = { userControl.currentMode = SpawnMode.WOLF },
                    colors = ButtonDefaults.buttonColors(
                        backgroundColor = if (userControl.currentMode == SpawnMode.WOLF) Color(0xFFFF5252) else Color(0xFF444444)
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("늑대 (Wolf) 스폰", color = Color.White)
                }

                Button(
                    onClick = { userControl.currentMode = SpawnMode.CAVE },
                    colors = ButtonDefaults.buttonColors(
                        backgroundColor = if (userControl.currentMode == SpawnMode.CAVE) Color(0xFF8B7A5E) else Color(0xFF444444)
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("동굴 (Cave) 스폰", color = Color.White)
                }
            }
        }
    }
}