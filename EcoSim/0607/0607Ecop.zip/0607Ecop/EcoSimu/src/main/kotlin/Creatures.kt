package eco

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

object SimConfig {
    const val GRASS_ZONE_MAX_HP = 200
    const val GRASS_ZONE_COUNT = 8
    const val GRASS_MAX_GROWTH = 30
    const val GRASS_MAX_ZONES_LIMIT = 20
    const val GRASS_EAT_AMOUNT = 5
    const val WOLF_BREED_ENERGY = 1400
    const val SHEEP_BREED_ENERGY = 900
}

enum class AnimalState { WANDER, CHASE, FLEE }

abstract class Animal(
    var x: Float,
    var y: Float,
    val maxEnergy: Int,
    val speed: Float,
    val vision: Double,
    val maxAge: Int
) {
    var energy: Int = maxEnergy
    var age: Int = 0
    var angle: Double = Random.nextDouble(0.0, 2 * PI)
    var state: AnimalState = AnimalState.WANDER
    var breedCount: Int = 0
    var isAlpha: Boolean = false

    abstract val energyLossRate: Int

    fun isHungry(): Boolean = energy < (maxEnergy * 0.6)

    fun checkBounds(width: Float, height: Float) {
        val margin = 30f
        if (x < margin) { x = margin; angle = PI - angle }
        if (x > width - margin) { x = width - margin; angle = PI - angle }
        if (y < margin) { y = margin; angle = -angle }
        if (y > height - margin) { y = height - margin; angle = -angle }
    }
}

class Wolf(
    x: Float, y: Float,
    val homeX: Float, val homeY: Float,
    initEnergy: Int,
    hungerThres: Int,
    visionRange: Double,
    maxAgeLimit: Int
) : Animal(x, y, maxEnergy = initEnergy, speed = 4.2f, vision = visionRange, maxAge = maxAgeLimit) {
    override val energyLossRate: Int = 2
}

class Sheep(
    x: Float, y: Float,
    initEnergy: Int,
    hungerThres: Int,
    visionRange: Double,
    maxAgeLimit: Int
) : Animal(x, y, maxEnergy = initEnergy, speed = 3.0f, vision = visionRange, maxAge = maxAgeLimit) {
    override val energyLossRate: Int = 1
}

data class GrassZone(
    var x: Float,
    var y: Float,
    val radius: Float = 60f,
    val maxHp: Int = SimConfig.GRASS_ZONE_MAX_HP,
    var hp: Int = maxHp
) {
    var growth: Int = 0

    fun respawn(width: Float, height: Float, caves: List<Cave>) {
        var valid = false
        while (!valid) {
            val rx = Random.nextFloat() * (width - 160f) + 80f
            val ry = Random.nextFloat() * (height - 160f) + 80f

            val nearCave = caves.any { cave ->
                val dx = (rx - cave.x).toDouble()
                val dy = (ry - cave.y).toDouble()
                (dx * dx + dy * dy) < (180.0 * 180.0)
            }
            if (!nearCave) {
                x = rx
                y = ry
                hp = maxHp
                growth = 0
                valid = true
            }
        }
    }

    fun calculateSpreadLocation(width: Float, height: Float): Pair<Float, Float> {
        val angle = Random.nextDouble(0.0, 2 * PI)
        val dist = Random.nextFloat() * 100f + 50f
        val nx = (x + cos(angle) * dist).toFloat().coerceIn(50f, width - 50f)
        val ny = (y + sin(angle) * dist).toFloat().coerceIn(50f, height - 50f)
        return Pair(nx, ny)
    }
}

data class Cave(
    val x: Float,
    val y: Float,
    val radius: Float = 40f,
    val name: String
)