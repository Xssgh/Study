package eco

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random
import java.util.concurrent.CopyOnWriteArrayList

class EcosystemEngine(val width: Float, val height: Float) {
    val animals = CopyOnWriteArrayList<Animal>()
    val grassZones = CopyOnWriteArrayList<GrassZone>() // 💡 구조 변경
    val caves = CopyOnWriteArrayList<Cave>()

    var wolfCount by mutableStateOf(0)
    var sheepCount by mutableStateOf(0)
    var totalGrassHp by mutableStateOf(0) // 💡 개수 대신 총 풀 체력 잔량을 UI에 표시

    fun tick() {
        // ⚡ 풀 자동 생성 차단 (초기 지정된 개수 내에서 리스폰으로 무한 순환하기 때문에 틱 연산 필요 없음)

        val currentAnimals = animals.toList()
        val wolves = currentAnimals.filterIsInstance<Wolf>()
        val sheeps = currentAnimals.filterIsInstance<Sheep>()

        val deadAnimals = mutableSetOf<Animal>()
        val newborns = mutableListOf<Animal>()

        var currentWolfCount = 0
        var currentSheepCount = 0

        for (current in currentAnimals) {
            if (deadAnimals.contains(current)) continue

            current.age += 1
            if (current.age >= current.maxAge) {
                deadAnimals.add(current)
                continue
            }

            current.energy -= current.energyLossRate
            if (current.energy <= 0) {
                deadAnimals.add(current)
                continue
            }

            // 늑대 로직
            if (current is Wolf) {
                var targetSheep: Sheep? = null
                if (current.isHungry()) {
                    var minSqDist = current.vision * current.vision
                    for (sheep in sheeps) {
                        if (deadAnimals.contains(sheep)) continue
                        val dx = (current.x - sheep.x).toDouble()
                        val dy = (current.y - sheep.y).toDouble()
                        val sqDist = dx * dx + dy * dy
                        if (sqDist < minSqDist) {
                            minSqDist = sqDist
                            targetSheep = sheep
                        }
                    }
                }

                if (targetSheep != null) {
                    current.state = AnimalState.CHASE
                    current.angle = atan2((targetSheep.y - current.y).toDouble(), (targetSheep.x - current.x).toDouble())

                    val dx = (current.x - targetSheep.x).toDouble()
                    val dy = (current.y - targetSheep.y).toDouble()
                    if ((dx * dx + dy * dy) < (8.0 * 8.0)) {
                        deadAnimals.add(targetSheep)
                        current.energy = current.maxEnergy
                    }
                } else {
                    current.state = AnimalState.WANDER

                    val dxHome = (current.x - current.homeX).toDouble()
                    val dyHome = (current.y - current.homeY).toDouble()
                    val sqDistToHome = dxHome * dxHome + dyHome * dyHome

                    if (sqDistToHome > (150.0 * 150.0)) {
                        current.angle = atan2((current.homeY - current.y).toDouble(), (current.homeX - current.x).toDouble())
                    }

                    if (current.energy >= SimConfig.WOLF_BREED_ENERGY && sqDistToHome < (100.0 * 100.0) && Random.nextFloat() < 0.05f) {
                        current.energy -= 600
                        newborns.add(
                            Wolf(
                                x = current.x + Random.nextFloat() * 20f - 10f,
                                y = current.y + Random.nextFloat() * 20f - 10f,
                                homeX = current.homeX,
                                homeY = current.homeY,
                                initEnergy = 1000,
                                hungerThres = Random.nextInt(400, 801),
                                visionRange = current.vision,
                                maxAgeLimit = Random.nextInt(2500, 3501)
                            )
                        )
                    }
                }
                if (!deadAnimals.contains(current)) currentWolfCount++
            }

            // 💡 [변경] 양 로직: 점이 아닌 영역(Zone)을 타깃팅
            else if (current is Sheep) {
                var threatWolf: Wolf? = null
                var minWolfSqDist = (current.vision * 0.6) * (current.vision * 0.6)

                for (wolf in wolves) {
                    val dx = (current.x - wolf.x).toDouble()
                    val dy = (current.y - wolf.y).toDouble()
                    val sqDist = dx * dx + dy * dy
                    if (sqDist < minWolfSqDist) {
                        minWolfSqDist = sqDist
                        threatWolf = wolf
                    }
                }

                if (threatWolf != null) {
                    current.state = AnimalState.FLEE
                    current.angle = atan2((threatWolf.y - current.y).toDouble(), (threatWolf.x - current.x).toDouble()) + Math.PI
                } else {
                    var targetZone: GrassZone? = null
                    if (current.isHungry()) {
                        var minZoneSqDist = current.vision * current.vision
                        // ⚡ 최적화 효과: 기존 수백 개 풀 리스트 순회 대신 30개 남짓한 구역 리스트만 순회함
                        for (zone in grassZones) {
                            if (zone.hp <= 0) continue
                            val dx = (current.x - zone.x).toDouble()
                            val dy = (current.y - zone.y).toDouble()
                            val sqDist = dx * dx + dy * dy
                            if (sqDist < minZoneSqDist) {
                                minZoneSqDist = sqDist
                                targetZone = zone
                            }
                        }
                    }

                    if (targetZone != null) {
                        current.state = AnimalState.CHASE
                        current.angle = atan2((targetZone.y - current.y).toDouble(), (targetZone.x - current.x).toDouble())

                        val dx = (current.x - targetZone.x).toDouble()
                        val dy = (current.y - targetZone.y).toDouble()
                        // 군락 반지름 범위(원 내부) 안으로 들어가면 뜯어먹기 동작 가동
                        val limitDist = targetZone.radius + 4f
                        if ((dx * dx + dy * dy) < (limitDist * limitDist)) {
                            if (targetZone.hp > 0) {
                                targetZone.hp -= SimConfig.GRASS_EAT_AMOUNT
                                current.energy = (current.energy + 40).coerceAtMost(current.maxEnergy)
                            }
                        }
                    } else {
                        current.state = AnimalState.WANDER

                        if (current.energy >= SimConfig.SHEEP_BREED_ENERGY && Random.nextFloat() < 0.02f) {
                            current.energy -= 500
                            newborns.add(
                                Sheep(
                                    x = current.x + Random.nextFloat() * 30f - 15f,
                                    y = current.y + Random.nextFloat() * 30f - 15f,
                                    initEnergy = 700,
                                    hungerThres = Random.nextInt(500, 801),
                                    visionRange = current.vision,
                                    maxAgeLimit = Random.nextInt(1500, 2501)
                                )
                            )
                        }
                    }
                }
                if (!deadAnimals.contains(current)) currentSheepCount++
            }

            if (current.state == AnimalState.WANDER && Random.nextFloat() < 0.12f) {
                current.angle += Random.nextDouble(-0.5, 0.5)
            }

            val currentSpeed = when (current.state) {
                AnimalState.CHASE -> current.speed * 1.1f
                AnimalState.FLEE -> current.speed * 1.0f
                AnimalState.WANDER -> current.speed * 0.5f
            }

            current.x += (cos(current.angle) * currentSpeed).toFloat()
            current.y += (sin(current.angle) * currentSpeed).toFloat()
            current.checkBounds(width, height)
        }

        // 💡 다 먹힌 풀 군락 검사 및 메모리 할당 없는 즉시 리스폰 처리
        var totalHpAccumulator = 0
        for (zone in grassZones) {
            if (zone.hp <= 0) {
                zone.respawn(width, height, caves)
            }
            totalHpAccumulator += zone.hp
        }

        if (deadAnimals.isNotEmpty()) animals.removeAll(deadAnimals)
        if (newborns.isNotEmpty()) {
            animals.addAll(newborns)
            newborns.forEach {
                if (it is Wolf) currentWolfCount++ else if (it is Sheep) currentSheepCount++
            }
        }

        wolfCount = currentWolfCount
        sheepCount = currentSheepCount
        totalGrassHp = totalHpAccumulator
    }
}