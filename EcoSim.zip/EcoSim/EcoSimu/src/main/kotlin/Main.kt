package eco

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Window
import androidx.compose.ui.window.application
import kotlinx.coroutines.delay
import kotlin.random.Random

fun main() = application {
    Window(onCloseRequest = ::exitApplication, title = "EcoSimu - 영역 기반 풀(체력형) 교체 버전") {

        val engine = remember { EcosystemEngine(1000f, 800f) }
        var tickTrigger by remember { mutableStateOf(0) }

        LaunchedEffect(Unit) {
            engine.caves.add(Cave(250f, 150f))
            engine.caves.add(Cave(750f, 150f))

            // 💡 초기 풀 군락(Zone) 분산 스폰 (상수 제어)
            repeat(SimConfig.GRASS_ZONE_COUNT) {
                val zone = GrassZone(0f, 0f)
                zone.respawn(1000f, 800f, engine.caves)
                engine.grassZones.add(zone)
            }

            // 늑대 30마리 스폰
            repeat(10) {
                val assignedCave = engine.caves.random()
                val randomEnergy = Random.nextInt(1000, 1501)
                val randomThreshold = Random.nextInt(400, 801)
                val randomVision = Random.nextDouble(180.0, 320.0)
                val randomMaxAge = Random.nextInt(2500, 3501)

                engine.animals.add(
                    Wolf(
                        x = assignedCave.x + Random.nextFloat() * 40f - 20f,
                        y = assignedCave.y + Random.nextFloat() * 40f - 20f,
                        homeX = assignedCave.x,
                        homeY = assignedCave.y,
                        initEnergy = randomEnergy,
                        hungerThres = randomThreshold,
                        visionRange = randomVision,
                        maxAgeLimit = randomMaxAge
                    )
                )
            }

            // 초기 양 300마리 스폰
            repeat(50) {
                val randomEnergy = Random.nextInt(700, 1001)
                val randomThreshold = Random.nextInt(500, 801)
                val randomVision = Random.nextDouble(150.0, 250.0)
                val randomMaxAge = Random.nextInt(1500, 2501)

                engine.animals.add(
                    Sheep(
                        x = Random.nextFloat() * 900f + 50f,
                        y = Random.nextFloat() * 350f + 400f,
                        initEnergy = randomEnergy,
                        hungerThres = randomThreshold,
                        visionRange = randomVision,
                        maxAgeLimit = randomMaxAge
                    )
                )
            }

            // 초기 카운트 계산 주입
            var initWolves = 0
            var initSheep = 0
            for (a in engine.animals) {
                if (a is Wolf) initWolves++ else if (a is Sheep) initSheep++
            }
            engine.wolfCount = initWolves
            engine.sheepCount = initSheep
            engine.totalGrassHp = engine.grassZones.sumOf { it.hp }

            while (true) {
                delay(60)
                engine.tick()
                tickTrigger++
            }
        }

        Box(modifier = Modifier.fillMaxSize()) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val dummy = tickTrigger

                // 1. 동굴 렌더링
                engine.caves.forEach { cave ->
                    drawRect(
                        color = Color.Gray,
                        topLeft = Offset(cave.x - (cave.radius / 2), cave.y - (cave.radius / 2)),
                        size = Size(cave.radius, cave.radius)
                    )
                }

                // 2. 💡 [변경] 풀 군락 영역 렌더링 (체력 수치에 비례해서 알파값/투명도 제어)
                engine.grassZones.forEach { zone ->
                    if (zone.hp > 0) {
                        val alphaRatio = zone.hp.toFloat() / zone.maxHp.toFloat()
                        drawCircle(
                            color = Color(0xFF4CAF50).copy(alpha = alphaRatio * 0.4f), // 남은 체력별 투명도 연출
                            radius = zone.radius,
                            center = Offset(zone.x, zone.y)
                        )
                        // 중심 점
                        drawCircle(
                            color = Color(0xFF2E7D32).copy(alpha = alphaRatio),
                            radius = 2.5f,
                            center = Offset(zone.x, zone.y)
                        )
                    }
                }

                // 3. 야생 동물 렌더링
                engine.animals.forEach { animal ->
                    val color = if (animal is Wolf) Color(0xFFE53935) else Color(0xFF2196F3)
                    val radius = if (animal is Wolf) 5f else 3f

                    drawCircle(
                        color = color,
                        radius = radius,
                        center = Offset(animal.x, animal.y)
                    )
                }
            }

            // 대시보드 스탯 창
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .background(Color(0x99000000))
                    .padding(12.dp)
            ) {
                Text(text = "늑대 (Wolf) : ${engine.wolfCount} 마리", color = Color(0xFFFF5252))
                Text(text = "양 (Sheep) : ${engine.sheepCount} 마리", color = Color(0xFF448AFF))
                Text(text = "생태계 총 풀 체력 : ${engine.totalGrassHp} HP", color = Color(0xFF69F0AE))
            }
        }
    }
}