package eco

import kotlin.random.Random

enum class AnimalState { WANDER, CHASE, FLEE }

object SimConfig {
    const val WOLF_MAX_ENERGY = 1500
    const val SHEEP_MAX_ENERGY = 1000
    const val WOLF_BREED_ENERGY = 1400
    const val SHEEP_BREED_ENERGY = 900

    // 💡 풀 군락 관련 설정 상수로 분리
    const val GRASS_ZONE_COUNT = 8      // 생성할 풀 군락 총 개수 (이 숫자로 고정됨)
    const val GRASS_ZONE_RADIUS = 35f     // 풀 영역 반지름
    const val GRASS_ZONE_MAX_HP = 200     // 풀 군락 최대 체력
    const val GRASS_EAT_AMOUNT = 5        // 양이 한 틱에 뜯어먹는 풀 체력 양
}

abstract class Animal(
    var x: Float,
    var y: Float,
    val type: String,
    var angle: Double = Random.nextDouble() * Math.PI * 2,
    val speed: Float,
    val maxEnergy: Int,
    var energy: Int,
    var state: AnimalState = AnimalState.WANDER,
    val energyLossRate: Int,
    val hungerThreshold: Int,
    val vision: Double,
    var age: Int = 0,
    val maxAge: Int
) {
    fun isHungry(): Boolean = this.energy <= this.hungerThreshold

    fun checkBounds(maxWidth: Float, maxHeight: Float) {
        if (x < 5f) { x = 5f; angle = Math.PI - angle }
        if (x > maxWidth - 5f) { x = maxWidth - 5f; angle = Math.PI - angle }
        if (y < 5f) { y = 5f; angle = -angle }
        if (y > maxHeight - 5f) { y = maxHeight - 5f; angle = -angle }

        val twoPi = Math.PI * 2
        angle = (angle % twoPi + twoPi) % twoPi
    }
}

class Wolf(
    x: Float, y: Float, val homeX: Float, val homeY: Float,
    initEnergy: Int, hungerThres: Int, visionRange: Double, maxAgeLimit: Int
) : Animal(
    x = x, y = y, type = "WOLF", speed = 4.5f,
    maxEnergy = SimConfig.WOLF_MAX_ENERGY, energy = initEnergy,
    energyLossRate = 2, hungerThreshold = hungerThres, vision = visionRange,
    maxAge = maxAgeLimit
)

class Sheep(
    x: Float, y: Float, initEnergy: Int, hungerThres: Int, visionRange: Double, maxAgeLimit: Int
) : Animal(
    x = x, y = y, type = "SHEEP", speed = 3.5f,
    maxEnergy = SimConfig.SHEEP_MAX_ENERGY, energy = initEnergy,
    energyLossRate = 1, hungerThreshold = hungerThres, vision = visionRange,
    maxAge = maxAgeLimit
)

// 💡 [변경] 점 데이터에서 체력과 영역을 가진 군락 데이터 구조로 업그레이드
class GrassZone(
    var x: Float,
    var y: Float,
    val radius: Float = SimConfig.GRASS_ZONE_RADIUS,
    var hp: Int = SimConfig.GRASS_ZONE_MAX_HP,
    val maxHp: Int = SimConfig.GRASS_ZONE_MAX_HP
) {
    // 늑대 동굴 피해가며 안전하게 새로운 무작위 위치로 재배치하는 함수
    fun respawn(maxWidth: Float, maxHeight: Float, caves: List<Cave>) {
        var validLocation = false
        var newX = 0f
        var newY = 0f

        while (!validLocation) {
            // X축은 양옆 벽 여유 공간 50f 주기
            newX = Random.nextFloat() * (maxWidth - 100f) + 50f

            // 💡 Y축을 화면 중간(maxHeight * 0.5f)부터 하단(maxHeight - 50f)까지로 제한
            val minY = maxHeight * 0.5f
            newY = minY + (Random.nextFloat() * (maxHeight - minY - 50f))

            // 혹시 모를 동굴 반경 체크 규칙은 안전장치로 유지
            val isNearCave = caves.any { cave ->
                val dx = (newX - cave.x).toDouble()
                val dy = (newY - cave.y).toDouble()
                (dx * dx + dy * dy) < (180.0 * 180.0)
            }
            if (!isNearCave) validLocation = true
        }

        this.x = newX
        this.y = newY
        this.hp = this.maxHp
    }
}
data class Cave(val x: Float, val y: Float, val radius: Float = 40f)
